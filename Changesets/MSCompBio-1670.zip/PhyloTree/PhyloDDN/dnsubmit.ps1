
$pieceCount = 30
$treeFile = "..\PhyloD\RegressionTest\Input\tree.03062007.txt"
$predictorFile = "..\PhyloD\RegressionTest\Input\hla.03062007.txt"
$targetFile = "..\PhyloD\RegressionTest\Input\aaPos.03062007.txt"
$leafDistribution = "DiscreteConditionalEscape"
$nullDataGenerator = "PredictorPermutation"
$niceName = "test03062007"
$nullIndexRange = "-1-9"
$digipedeHost = "shuttle01"
$digipedeUser = "nathan"
$digipedePassword = "nathan"
$poolId = 1

bin\release\phyloddn.exe -poolid $poolId -host $digipedeHost -u $digipedeUser -p $digipedePassword $pieceCount $treeFile $predictorFile $targetFile $leafDistribution $nullDataGenerator $niceName $nullIndexRange
