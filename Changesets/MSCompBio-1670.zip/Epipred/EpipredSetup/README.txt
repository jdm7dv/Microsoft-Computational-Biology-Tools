For documenation, see
http://www.codeplex.com/MSCompBio