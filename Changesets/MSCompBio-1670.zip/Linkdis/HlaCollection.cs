using System; 
using System.Collections.Generic;
using System.Data.Common;
using System.Diagnostics;
using System.Text;

using Msr.Mlas.SpecialFunctions; 
using EpipredLib; 
using VirusCount.Qmrr;
 
namespace Msr.Linkdis
{
    public class HlaCollection
    {
        private HlaCollection()
        { 
        } 

        private HlaFactory HlaFactory; 
        Dictionary<string, List<Hla>> ClassToHlaSet;
        public double Weight = 1.0;

        public static HlaCollection GetInstance(HlaFactory hlaFactory, DbDataReader reader, List<string> hlaColumnList)
        {
            HlaCollection hlaCollection = new HlaCollection(); 
            hlaCollection.HlaFactory = hlaFactory; 
            hlaCollection.ClassToHlaSet = new Dictionary<string, List<Hla>>();
            SpecialFunctions.CheckCondition(hlaColumnList.Count == 6); //!!!const 
            foreach (string hlaColumnName in hlaColumnList)
            {
                Debug.Assert(hlaColumnName != ""); // real assert
                string hlaName0 = reader.GetString(reader.GetOrdinal(hlaColumnName));
                string hlaName1 = hlaCollection.FixUpHlaName(hlaName0);
                Hla hla = hlaCollection.HlaFactory.GetGroundOrAbstractInstance(hlaName1); 
                string hlaClass = hlaColumnName.Substring(0, 1).ToUpper(); 
                SpecialFunctions.CheckCondition(hlaClass == "A" || hlaClass == "B" || hlaClass == "C"); //!!!const
                List<Hla> hlaList = SpecialFunctions.GetValueOrDefault(hlaCollection.ClassToHlaSet, hlaClass); 
                hlaList.Add(hla);
            }
            hlaCollection.CheckAndSort();
            return hlaCollection;
        }
 
        private string FixUpHlaName(string hlaName) 
        {
            SpecialFunctions.CheckCondition(hlaName != ""); 
            string hlaClass = hlaName.Substring(0, 1);
            SpecialFunctions.CheckCondition(hlaClass == "A" || hlaClass == "B" || hlaClass == "C"); //!!!const
            List<string> suffixList = new List<string>();
            foreach (string suffix in hlaName.Substring(1).Split('/'))
            {
                if (suffix.Length == 4) 
                { 
                    suffixList.Add(suffix);
                } 
                else if (suffix.Length == 2)
                {
                    suffixList.Add(suffix + "??");
                }
                else if (suffix.Length == 0)
                { 
                    suffixList.Add(suffix + "????"); 
                }
                else 
                {
                    SpecialFunctions.CheckCondition(false, "Don't know how to pad " + suffix);
                }
            }
            string newName = hlaClass + SpecialFunctions.Join("/", suffixList);
            return newName; 
        } 

        private void CheckAndSort() 
        {
            foreach(string hlaClass in new string[]{"A", "B", "C"})
            {
                SpecialFunctions.CheckCondition(ClassToHlaSet.ContainsKey(hlaClass));
                List<Hla> hlaList = ClassToHlaSet[hlaClass];
                SpecialFunctions.CheckCondition(hlaList.Count == 2); 
                hlaList.Sort(delegate(Hla hla1, Hla hla2) { return hla1.ToString().CompareTo(hla2.ToString()); }); 
            }
        } 

        public override string ToString()
        {
            List<string> asStringList = new List<string>();
            foreach (List<Hla> hlaList in ClassToHlaSet.Values)
            { 
                asStringList.Add(SpecialFunctions.Join("\t", hlaList)); 
            }
 
            string asString = SpecialFunctions.Join("\t", asStringList) + "\t" + Weight.ToString();
            return asString;
        }

        internal List<string> ClassList()
        { 
            List<string> rg = new List<string>(ClassToHlaSet.Keys); 
            rg.Sort();
            return rg; 
        }

        internal List<Hla> ByClass(string hlaClass)
        {
            return ClassToHlaSet[hlaClass];
        } 
 
        internal static HlaCollection GetLessAbstractInstance(HlaCollection hlaCollectionOld, Dictionary<Hla, Set<Hla>> hlaToGroundHlaSet)
        { 
            HlaCollection hlaCollection = new HlaCollection();
            hlaCollection.HlaFactory = hlaCollectionOld.HlaFactory;
            hlaCollection.ClassToHlaSet = new Dictionary<string, List<Hla>>();
            foreach(string hlaClass in hlaCollectionOld.ClassList())
            {
                List<Hla> hlaList = new List<Hla>(); 
                foreach (Hla hlaOld in hlaCollectionOld.ClassToHlaSet[hlaClass]) 
                {
                    Hla hlaNew; 
                    Set<Hla> groundHlaSet = hlaToGroundHlaSet[hlaOld];
                    if (groundHlaSet.Count == 1)
                    {
                        hlaNew = groundHlaSet.AnyElement();
                    }
                    else if (groundHlaSet.Count == 0) 
                    { 
                        SpecialFunctions.CheckCondition(!hlaOld.ToString().Contains("/"),
                            string.Format("None of HLAs that make up '{0}' every appear as singletons so it can not processed.", hlaOld));
                        hlaNew = hlaCollection.HlaFactory.GetGroundInstance(hlaOld.ToString().Replace('?', '@')); 
                    }
                    else
                    {
                        hlaNew = hlaOld;
                    }
                    hlaList.Add(hlaNew); 
                } 
                hlaCollection.ClassToHlaSet.Add(hlaClass, hlaList);
            } 

            hlaCollection.CheckAndSort();
            return hlaCollection;
        }

        internal static HlaCollection GetExpandedInstance(HlaCollection hlaCollectionOld, string targetHlaClass, int columnStartIndex, Hla newValue, double probability) 
        { 
            Hla hla = hlaCollectionOld.ByClass(targetHlaClass)[columnStartIndex];
 
            if (hla == newValue)
            {
                Debug.Assert(probability == 1.0); // real assert
                return hlaCollectionOld;
            }
 
            HlaCollection hlaCollection = new HlaCollection(); 

            hlaCollection.HlaFactory = hlaCollectionOld.HlaFactory; 
            hlaCollection.ClassToHlaSet = new Dictionary<string, List<Hla>>();
            hlaCollection.Weight = hlaCollectionOld.Weight * probability;

            foreach (KeyValuePair<string, List<Hla>> hlaClassAndHlaList in hlaCollectionOld.ClassToHlaSet)
            {
                string hlaClass = hlaClassAndHlaList.Key; 
                List<Hla> hlaListOld = hlaClassAndHlaList.Value; 

                if (hlaClass != targetHlaClass) 
                {
                    hlaCollection.ClassToHlaSet.Add(hlaClass, hlaListOld);
                }
                else
                {
                    List<Hla> hlaList = new List<Hla>(); 
                    for (int i = 0; i < hlaListOld.Count; ++i) 
                    {
                        if (i == columnStartIndex) 
                        {
                            hlaList.Add(newValue);
                        }
                        else
                        {
                            hlaList.Add(hlaListOld[i]); 
                        } 
                    }
                    hlaCollection.ClassToHlaSet.Add(hlaClass, hlaList); 
                }
            }

            hlaCollection.CheckAndSort();
            return hlaCollection;
        } 
    } 
}
 
// Microsoft Research, Machine Learning and Applied Statistics Group, Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved.
