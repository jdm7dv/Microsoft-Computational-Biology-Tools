using System; 
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using Msr.Mlas.SpecialFunctions;
using VirusCount.Qmrr;
using VirusCount; 
using System.Reflection; 
using System.IO;
 
internal class TempDirectory : IDisposable
{
 	private string tempFileName = System.IO.Path.GetTempFileName();
	private string tempDirectoryName;

	public TempDirectory(string name) 
	{ 
		tempDirectoryName = tempFileName + "." + name + "\\";
	} 

 	~TempDirectory()
 	{
		Dispose();
 	}
 
	public virtual void Dispose() 
	{
		if (Directory.Exists(tempDirectoryName)) 
		{
			Directory.Delete(tempDirectoryName, true);
 		}

 		if (File.Exists(tempFileName))
		{ 
 			File.Delete(tempFileName); 
		}
	} 

	public string Path
	{
		get { return tempDirectoryName; }
 	}
}; 
 

namespace Msr.Linkdis 
{
 	public class HlaLogisticRegression
	{
 		TempDirectory tempDirectory = new TempDirectory("MultiMax");

		public HlaDistribution LearnLogisticRegressionModel( 
			HlaFactory hlaFactory, 
			KeyValuePair<string, List<Dictionary<string, string>>> targetAndTrainingData,
			string[] givenHlaClassCollection, 
			double smoothingParameter)
 		{
 			string exeDirectoryName = ExeDirectory;
			string target = targetAndTrainingData.Key;
 			List<Dictionary<string, string>> trainingSet = targetAndTrainingData.Value;
			HlaDistribution aHlaDistribution = HlaDistribution.GetInstance(hlaFactory, target, trainingSet); 
 
			if (aHlaDistribution.Count > 1)
			{ 
				string tempDirectoryName = tempDirectory.Path;

				if (!Directory.Exists(tempDirectoryName))
 				{
 					Directory.CreateDirectory(tempDirectoryName);
				} 
 
 				SerialNumbers<string> featureSerialNumbers = CreateFeatureSerialNumbers(target, trainingSet);
				SerialNumbers<string> classSerialNumbers; 
				string txtFile    = CreateMultiMaxInputFile(tempDirectoryName, target, trainingSet, featureSerialNumbers, out classSerialNumbers);
				string weightFile = RunMultiMax(tempDirectoryName, txtFile, target, smoothingParameter);

				aHlaDistribution = MulticlassLogisticRegression.GetInstance(hlaFactory, target, givenHlaClassCollection, weightFile, featureSerialNumbers, classSerialNumbers);
			}
 
 			return aHlaDistribution; 
 		}
 
		static private string ExeDirectory
 		{
			get
			{
				string exeDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase);
				return exeDir.StartsWith(@"file:\") ? exeDir.Substring(6) : exeDir; 
			} 
 		}
 
 		static private string RunMultiMax(string tempDirectoryName, string txtFile, string target, double sigmaSquared)
		{
 			string weightFile = string.Format("{0}{1}{2}", tempDirectoryName, target, ".weights.txt");
			//-numiterations 100
			HlaDistribution.RunProgram(ExeDirectory, "multimax.exe", string.Format(@"-writeweights ""{0}"" -sigma_squared {1} ""{2}"" NUL", weightFile, sigmaSquared, txtFile));
			return weightFile; 
		} 

		private static string CreateMultiMaxInputFile(string tempDirectoryName, string target, List<Dictionary<string, string>> trainingSet, 
 				SerialNumbers<string> featureSerialNumbers, out SerialNumbers<string> classSerialNumbers)
 		{
			classSerialNumbers = SerialNumbers<string>.GetInstance();

 			string txtFile = string.Format(@"{0}{1}{2}", tempDirectoryName, target, ".txt");
			using (TextWriter txtTextWriter = File.CreateText(txtFile)) 
			{ 
				foreach (Dictionary<string, string> winmineCase in trainingSet)
				{ 
					string classString = winmineCase[target];
 					int classSerialNumber = classSerialNumbers.GetNewOrOld(classString);
 					txtTextWriter.Write(classSerialNumber);
					for (int iFeature = 0; iFeature < featureSerialNumbers.Count; ++iFeature)
 					{
						string featureName = featureSerialNumbers.GetItem(iFeature); 
						txtTextWriter.Write(" {0}", winmineCase.ContainsKey(featureName) ? 1 : 0); 
					}
					txtTextWriter.WriteLine(""); 
				}
 			}

 			WriteClassStatesAndFeatureNames(tempDirectoryName, target, featureSerialNumbers, classSerialNumbers);
			return txtFile;
 		} 
 
		private static void WriteClassStatesAndFeatureNames(string tempDirectoryName, string target, SerialNumbers<string> featureSerialNumbers, SerialNumbers<string> classSerialNumbers)
		{ 
			string classAndFeatureFile = string.Format(@"{0}{1}{2}", tempDirectoryName, target, ".classAndFeature.txt");
			using (TextWriter classAndFeatureTextWriter = File.CreateText(classAndFeatureFile))
			{
 				WriteClassStates(classSerialNumbers, classAndFeatureTextWriter);

 				WriteFeatureNames(featureSerialNumbers, classAndFeatureTextWriter); 
 
			}
 
 		}

		private static void WriteFeatureNames(SerialNumbers<string> featureSerialNumbers, TextWriter classAndFeatureTextWriter)
		{
			classAndFeatureTextWriter.WriteLine("Features");
			foreach (string featureName in featureSerialNumbers.Items()) 
			{ 
 				classAndFeatureTextWriter.WriteLine(featureName);
 			} 
			classAndFeatureTextWriter.WriteLine("");
 		}

		private static void WriteClassStates(SerialNumbers<string> classSerialNumbers, TextWriter classAndFeatureTextWriter)
		{
			classAndFeatureTextWriter.WriteLine("Class States"); 
			foreach (string className in classSerialNumbers.Items()) 
			{
 				classAndFeatureTextWriter.WriteLine(className); 
 			}
			classAndFeatureTextWriter.WriteLine("");
 		}

		private static SerialNumbers<string> CreateFeatureSerialNumbers(string target, List<Dictionary<string, string>> trainingSet)
		{ 
			SerialNumbers<string> featureSerialNumbers = SerialNumbers<string>.GetInstance(); 
			foreach (Dictionary<string, string> winmineCase in trainingSet)
			{ 
 				foreach (KeyValuePair<string, string> variableAndValue in winmineCase)
 				{
					string variable = variableAndValue.Key;
 					if (variable != target)
					{
						Debug.Assert("1" == variableAndValue.Value); // real assert 
						featureSerialNumbers.GetNewOrOld(variable); 
					}
				} 
 			}
 			return featureSerialNumbers;
		}

 	}
} 
 
// Microsoft Research, Machine Learning and Applied Statistics Group, Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved. 
