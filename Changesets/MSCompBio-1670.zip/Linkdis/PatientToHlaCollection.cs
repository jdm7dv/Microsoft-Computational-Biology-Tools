using System; 
using System.Collections.Generic;
using System.Data.Common;
using System.Diagnostics;
using System.IO;
using System.Text;
 
using EpipredLib; 
using VirusCount.Qmrr;
using Msr.Mlas.SpecialFunctions; 
using VirusCount;


namespace Msr.Linkdis
{
    public class PatientToHlaCollection 
    { 
        private PatientToHlaCollection()
        { 
        }

        private Dictionary<string, List<HlaCollection>> PidToHlaCollectionList;

        static string PidColumnName = "pid";
        static string HlaColumnListName = SpecialFunctions.CreateTabString("A1", "A2", "B1", "B2", "C1", "C2"); 
        static List<string> HlaColumnList 
        {
            get 
            {
                return SpecialFunctions.Split(HlaColumnListName, '\t');
            }
        }
        static string InputHeader
        { 
            get 
            {
                return SpecialFunctions.CreateTabString(PidColumnName, HlaColumnListName); 
            }
        }
        public static PatientToHlaCollection GetInstance(HlaFactory hlaFactory, TextReader trainingText)
        {
            PatientToHlaCollection patientToHlaCollection = new PatientToHlaCollection();
            patientToHlaCollection.PidToHlaCollectionList = new Dictionary<string, List<HlaCollection>>(); 
 
 			using (DbDataReader reader = new StreamDataReader(trainingText))
			{ 
				int		indexPid = reader.GetOrdinal("pid");

				while (reader.Read())
				{
					HlaCollection hlaCollection = HlaCollection.GetInstance(hlaFactory, reader, HlaColumnList);
 					patientToHlaCollection.PidToHlaCollectionListAddNew(reader.GetString(indexPid), hlaCollection); 
 				} 

				patientToHlaCollection.SetTheHlaSet(); 
 			}

            return patientToHlaCollection;
        }

        private void PidToHlaCollectionListAddNew(string pid, HlaCollection hlaCollection) 
        { 
            SpecialFunctions.CheckCondition(!PidToHlaCollectionList.ContainsKey(pid));
            List<HlaCollection> hlaCollectionList = new List<HlaCollection>(); 
            hlaCollectionList.Add(hlaCollection);
            PidToHlaCollectionList.Add(pid, hlaCollectionList);
        }

        private void PidToHlaCollectionListAddNewOrOld(string pid, HlaCollection hlaCollection)
        { 
            List<HlaCollection> hlaCollectionList = SpecialFunctions.GetValueOrDefault(PidToHlaCollectionList, pid); 
            hlaCollectionList.Add(hlaCollection);
        } 


        public Set<Hla> PossibleGroundHlaSet(Hla hla)
        {
            if (hla.IsGround)
            { 
                return Set<Hla>.GetInstance(hla); 
            }
            else 
            {
                Set<Hla> possibleGroundHlaSet = Set<Hla>.GetInstance();
                foreach (Hla possibleGroundHla in HlaSet)
                {
                    if (possibleGroundHla.IsGround)
                    { 
                        if (hla.IsMoreGeneralThan(possibleGroundHla)) 
                        {
                            possibleGroundHlaSet.AddNew(possibleGroundHla); 
                        }
                    }
                }
                return possibleGroundHlaSet;
            }
        } 
 

 
        public IEnumerable<KeyValuePair<string, List<HlaCollection>>> PatientAndHlaCollectionList()
        {
            foreach (KeyValuePair<string, List<HlaCollection>> patientAndHlaCollectionList in PidToHlaCollectionList)
            {
                yield return patientAndHlaCollectionList;
            } 
        } 

        public IEnumerable<KeyValuePair<string, HlaCollection>> PatientAndHlaCollectionOrNull() 
        {
            foreach (KeyValuePair<string, List<HlaCollection>> patientAndHlaCollectionList in PidToHlaCollectionList)
            {
                List<HlaCollection> hlaCollectionList = patientAndHlaCollectionList.Value;
                if (hlaCollectionList.Count == 0)
                { 
                    yield return new KeyValuePair<string, HlaCollection>(patientAndHlaCollectionList.Key, null); 
                }
                else 
                {
                    foreach (HlaCollection hlaCollection in hlaCollectionList)
                    {
                        yield return new KeyValuePair<string, HlaCollection>(patientAndHlaCollectionList.Key, hlaCollection);
                    }
                } 
            } 
        }
 
        public Set<Hla> HlaSet;
        private void SetTheHlaSet()
        {
            HlaSet = Set<Hla>.GetInstance();
            foreach (List<HlaCollection> hlaCollectionList in PidToHlaCollectionList.Values)
            { 
                foreach (HlaCollection hlaCollection in hlaCollectionList) 
                {
                    foreach (string hlaClass in hlaCollection.ClassList()) 
                    {
                        HlaSet.AddNewOrOldRange(hlaCollection.ByClass(hlaClass));
                    }
                }
            }
        } 
 
        internal static PatientToHlaCollection GetLessAbstractInstance(PatientToHlaCollection fromFile)
        { 
            Dictionary<Hla, Set<Hla>> hlaToGroundHlaSet = fromFile.CreateHlaToGroundHlaSet();

            PatientToHlaCollection patientToHlaCollection = new PatientToHlaCollection();
            patientToHlaCollection.PidToHlaCollectionList = new Dictionary<string, List<HlaCollection>>();
            foreach (KeyValuePair<string, List<HlaCollection>> patientAndHlaCollectionList in fromFile.PatientAndHlaCollectionList())
            { 
                string pid = patientAndHlaCollectionList.Key; 
                foreach (HlaCollection hlaCollectionOld in patientAndHlaCollectionList.Value)
                { 
                    Debug.Assert(hlaCollectionOld.Weight == 1.0); // real assert
                    HlaCollection hlaCollectionNew = HlaCollection.GetLessAbstractInstance(hlaCollectionOld, hlaToGroundHlaSet);
                    patientToHlaCollection.PidToHlaCollectionListAddNew(pid, hlaCollectionNew);
                }
            }
 
 
            patientToHlaCollection.SetTheHlaSet();
            return patientToHlaCollection; 


        }

        private Dictionary<Hla, Set<Hla>> CreateHlaToGroundHlaSet()
        { 
            Dictionary<Hla, Set<Hla>> hlaToGroundHlaSet = new Dictionary<Hla, Set<Hla>>(); 
            foreach (Hla hla in HlaSet)
            { 
                Set<Hla> possibleGroundInstances = PossibleGroundHlaSet(hla);
                hlaToGroundHlaSet.Add(hla, possibleGroundInstances);
            }
            return hlaToGroundHlaSet;
        }
 
        public static PatientToHlaCollection GetExpandedInstance( 
                IEnumerable<KeyValuePair<string, HlaCollection>> tableIn,
                string targetHlaClass, 
                Dictionary<string, HlaDistribution> targetToModel)
        {
            PatientToHlaCollection expandedTable = new PatientToHlaCollection();
            expandedTable.PidToHlaCollectionList = new Dictionary<string, List<HlaCollection>>();
            foreach (KeyValuePair<string, HlaCollection> patientAndHlaCollectionOrNullOld in tableIn)
            { 
                string pid = patientAndHlaCollectionOrNullOld.Key; 
                HlaCollection hlaCollectionOrNullOld = patientAndHlaCollectionOrNullOld.Value;
 
                List<HlaCollection> more = ExpandWithModel(targetHlaClass, 0, hlaCollectionOrNullOld, targetToModel);

                List<HlaCollection> hlaCollectionNew = SpecialFunctions.GetValueOrDefault(expandedTable.PidToHlaCollectionList, pid);
                hlaCollectionNew.AddRange(more);
            }
            expandedTable.SetTheHlaSet(); 
            return expandedTable; 
        }
 
        static private List<HlaCollection> ExpandWithModel(
                string targetHlaClass,
                int columnStartIndex,
                HlaCollection hlaCollectionOrNull,
                Dictionary<string, HlaDistribution> targetToModel)
        { 
            if (null == hlaCollectionOrNull) 
            {
                return new List<HlaCollection>(); 
            }

            List<Hla> hlaList = hlaCollectionOrNull.ByClass(targetHlaClass);

            if (columnStartIndex < hlaList.Count)
            { 
                Hla hla = hlaList[columnStartIndex]; 
                Dictionary<Hla, double> newValueDistribution = ExpandValue(hlaCollectionOrNull, hla, targetToModel);
                if (newValueDistribution == null) 
                {
                    return new List<HlaCollection>();
                }

                List<HlaCollection> restExpanded = ExpandWithModel(targetHlaClass, columnStartIndex + 1, hlaCollectionOrNull, targetToModel);
                if (restExpanded == null) 
                { 
                    SpecialFunctions.CheckCondition(false, "Is this right?");
                    return null; 
                }

                List<HlaCollection> newRows = new List<HlaCollection>();
                foreach (HlaCollection rowExpanded in restExpanded)
                {
                    foreach (KeyValuePair<Hla, double> newValueAndProbability in newValueDistribution) 
                    { 
                        Hla newValue = newValueAndProbability.Key;
                        //SpecialFunctions.CheckCondition(newValue == null || char.IsDigit(newValue[0])); 
                        HlaCollection newRow = HlaCollection.GetExpandedInstance(rowExpanded, targetHlaClass, columnStartIndex, newValue, newValueAndProbability.Value);
                        newRows.Add(newRow);
                    }
                }
                return newRows;
            } 
            else 
            {
                List<HlaCollection> singleton = new List<HlaCollection>(); 
                singleton.Add(hlaCollectionOrNull);
                return singleton;
            }
        }

 
        static private Dictionary<Hla, double> ExpandValue(HlaCollection hlaCollectionOrNull, Hla hla, Dictionary<string, HlaDistribution> targetToModel) 
        {
            if (null == hlaCollectionOrNull) 
            {
                return null;
            }

            if (null == hla)
            { 
                SpecialFunctions.CheckCondition(false, "Is this code used? needed? right?"); 
                Dictionary<Hla, double> multinomial = new Dictionary<Hla, double>();
                multinomial.Add(null, 1.0); 
                return multinomial;
            }
            else if (hla.IsGround)
            {
                return HlaDistribution.GetInstance(hla).Evaluate(hlaCollectionOrNull); //!!!inefficent
            } 
 
            else if (hla.ToString().Substring(1) == "????")
            { 
                return null;
            }
            else
            {

                Set<string> possiblePrefixes = Set<string>.GetInstance(); 
                foreach (string part in hla.ToString().Substring(1).Split('/')) 
                {
                    Debug.Assert(part.Length == 4); // real assert 
                    Debug.Assert(part.Substring(0, 2) != "??");
                    possiblePrefixes.AddNewOrOld(hla.ToString().Substring(0, 1) + part.Substring(0, 2));
                }
                Debug.Assert(possiblePrefixes.Count > 0); // real assert

                if (possiblePrefixes.Count > 1) 
                { 
                    return null;
                } 

                Debug.Assert(possiblePrefixes.Count == 1);
                string variable = possiblePrefixes.AnyElement();

                SpecialFunctions.CheckCondition(targetToModel.ContainsKey(variable));
                HlaDistribution hlaDistributionAll = targetToModel[variable]; 
 
                Dictionary<Hla, double> multinomial = hlaDistributionAll.Contrained(hlaCollectionOrNull, hla);
                return multinomial; 
            }

            //if (lnn0n_nPattern.IsMatch(hla))
            //{
            //    string[] valueCollection;
            //    string variable = GetVariableFromSlashed1(hlaCollection, column, out valueCollection); 
            //    SpecialFunctions.CheckCondition(targetToModel.ContainsKey(variable)); 
            //    HlaDistribution hlaDistributionAll = targetToModel[variable];
            //    Dictionary<string, double> contrained = hlaDistributionAll.Contrained(hlaCollection, valueCollection); 
            //    return contrained;
            //}
            //else if (lnnnn_nnnnPattern.IsMatch(hla))
            //{
            //    string[] valueCollection;
            //    string variable = GetVariableFromSlashed2(hlaCollection, column, out valueCollection); 
            //    SpecialFunctions.CheckCondition(targetToModel.ContainsKey(variable)); 
            //    HlaDistribution hlaDistributionAll = targetToModel[variable];
            //    Dictionary<string, double> contrained = hlaDistributionAll.Contrained(hlaCollection, valueCollection); 
            //    return contrained;

            //    {
            //    string variable = GetVariable(hlaCollection, column);
            //    SpecialFunctions.CheckCondition(targetToModel.ContainsKey(variable));
            //    Dictionary<string, double> multinomial = targetToModel[variable].Evaluate(hlaCollection); 
            //    return multinomial; 
            //}
        } 


        internal List<HlaCollection> GetHlaCollectionList(string pid)
        {
            return PidToHlaCollectionList[pid];
        } 
 
    }
} 

// Microsoft Research, Machine Learning and Applied Statistics Group, Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved.
