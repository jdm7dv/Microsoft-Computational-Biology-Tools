using System; 
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using Msr.Mlas.SpecialFunctions;
using VirusCount.Qmrr;
using VirusCount; 
using System.Reflection; 
using System.IO;
 
namespace Msr.Linkdis
{
    public static class HlaMultinomial
    {
        public static HlaDistribution LearnMultinomial(
            HlaFactory hlaFactory, 
            KeyValuePair<string, List<Dictionary<string, string>>> targetAndTrainingData, 
            string[] givenHlaClassCollection,
            double smoothingParameter) 
        {
            string exeDirectoryName = Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetModules()[0].FullyQualifiedName); // See MSDN titled: How to: Get the Application Directory

            string target = targetAndTrainingData.Key;
            List<Dictionary<string, string>> trainingSet = targetAndTrainingData.Value;
            HlaDistribution aHlaDistribution = HlaDistribution.GetInstance(hlaFactory, target, trainingSet, smoothingParameter); 
 
            return aHlaDistribution;
        } 
    }
}

// Microsoft Research, Machine Learning and Applied Statistics Group, Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved.
