using System; 

namespace Msr.Mlas.LinearAlgebra
{
    public class ComplexArray
    {
        public ComplexArray(double[,] arrreal, double[,] arrimag) { throw new Exception("The method or operation is not implemented."); } 
        public ComplexArray Inv(){ throw new Exception("The method or operation is not implemented."); } 
        public int[] Size() { throw new Exception("The method or operation is not implemented."); }
        public void ToArray(ref double[,] arrreal, ref double[,] arrimag) { throw new Exception("The method or operation is not implemented."); } 
    }
}

// Microsoft Research, Machine Learning and Applied Statistics Group, Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved.
