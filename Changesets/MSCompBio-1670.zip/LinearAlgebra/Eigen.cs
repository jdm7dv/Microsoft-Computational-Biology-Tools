using System; 

namespace Msr.Mlas.LinearAlgebra
{
    public class Eigen
    {
        public Eigen(DoubleArray A){ throw new Exception("The method or operation is not implemented."); } 
 
        public ComplexArray D { get { throw new Exception("The method or operation is not implemented."); } }
        public ComplexArray V { get { throw new Exception("The method or operation is not implemented."); } } 
    }
}

// Microsoft Research, Machine Learning and Applied Statistics Group, Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved.
