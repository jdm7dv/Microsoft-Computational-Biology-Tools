using System; 
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using Msr.Mlas.SpecialFunctions;
using Msr.Linkdis;
using VirusCount.Qmrr; 
using VirusCount; 
using System.IO;
 
namespace Msr.Linkdis
{
    class LinkdisMain
    {
        static void Main(string[] args)
        { 
            string learnerListString = SpecialFunctions.Join(",", Linkdis.LearnerEnumeration); 

            try 
            {

                // Parse arguments
                ArgCollection argCollection = ArgCollection.GetInstance(args);

                string learnerName = argCollection.ExtractOptional<string>("learner", Linkdis.DefaultLearner); 
 
                double defaultSmoothingParameter;
                SpecialFunctions.CheckCondition(Linkdis.LearnerToDefaultSmoothingParameter.TryGetValue(learnerName, out defaultSmoothingParameter), 
                    string.Format("The learner parameter must be one of these: {0}", learnerListString));

                double smoothingParameter = argCollection.ExtractOptional<double>("smoothingParameter", defaultSmoothingParameter);
                string inputFileName = argCollection.ExtractNext<string>("inputFile");
                string expandedFileName = argCollection.ExtractNext<string>("expandedFile");
                string lineByLineFileName = argCollection.ExtractNext<string>("lineByLineFile"); 
                argCollection.CheckThatEmpty(); 

                Linkdis linkdis = Linkdis.GetInstance(inputFileName, learnerName, smoothingParameter); 
                linkdis.ExpandAndReport(inputFileName, expandedFileName, lineByLineFileName);

            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message); 
                if (exception.InnerException != null) 
                {
                    Console.WriteLine(exception.InnerException.Message); 
                }

                string paramListString = SpecialFunctions.Join(";", Linkdis.LearnerToDefaultSmoothingParameter);

                Console.Error.WriteLine(@"
 
USAGE 

Linkdis {{-learner LEARNER}} {{-smoothingParameter SMOOTHINGPARAMETER}} inputFileName expandedFileName lineByLineFileName 
where LEARNER is one of {0}.
The default learner is {1}.
SMOOTHINGPARAMETER is a double.
The default SMOOTHINGPARAMETER depends on the LEARNER:
    {2}
", 
 learnerListString, 
 Linkdis.DefaultLearner,
 paramListString 
                    );

                System.Environment.Exit(-1);
            }
        }
    } 
} 

// Microsoft Research, Machine Learning and Applied Statistics Group, Shared Source. 
// Copyright (c) Microsoft Corporation. All rights reserved.
