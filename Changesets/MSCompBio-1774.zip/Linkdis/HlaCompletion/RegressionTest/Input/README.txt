This data is based on (but is not identical to):

http://www.hiv.lanl.gov/content/immunology/alabama/subjects.html

According to http://www.hiv.lanl.gov/content/immunology/alabama/, the study is described in 

S. Sabbaj, A. Bansal, G. D. Ritter, C. Perkins, B. H. Edwards, E. Gough, J. Tang, J. J. Szinger, B. Korber, C. M. Wilson, R. A. Kaslow, M. J. Mulligan, and P. A. Goepfert. "Cross-reactive CD8+ T cell epitopes identified in US adolescent minorities". Journal of Acquired Immune Deficiency Syndromes, 33(4):426-438, 1 August 2003. 
and 
A. Bansal, S. Sabbaj, B. H. Edwards, G. D. Ritter, C. Perkins, J. Tang, J. J. Szinger, H. Weiss, P. A. Goepfert, B. Korber, C. M. Wilson, R. A. Kaslow, and M. J. Mulligan. "T-cell responses to Gag, Pol, Env and Nef in HIV-1-infected African-American and Hispanic adolescents". AIDS Research and Human Retroviruses. Accepted May 2003. 