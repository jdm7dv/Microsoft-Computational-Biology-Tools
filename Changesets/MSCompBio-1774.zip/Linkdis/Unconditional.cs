using System; 
using System.Collections.Generic;
using System.Text;
using Msr.Mlas.SpecialFunctions;
using VirusCount;
using EpipredLib;
 
namespace Msr.Linkdis 
{
    public class Unconditional : HlaDistribution 
    {
        internal Dictionary<Hla, double> Multinomial = new Dictionary<Hla, double>();
        internal Unconditional()
        {
        }
 
        internal static Unconditional GetInstance(List<Hla> stateCollection, string[] probsAsString) 
        {
            SpecialFunctions.CheckCondition(stateCollection.Count == probsAsString.Length); 

            Unconditional unconditional = new Unconditional();
            for (int iState = 0; iState < stateCollection.Count; ++iState)
            {
                Hla state = stateCollection[iState];
                unconditional.Add(state, double.Parse(probsAsString[iState])); 
            } 
            return unconditional;
        } 

        internal void Add(Hla value, double p)
        {
            //SpecialFunctions.CheckCondition(char.IsLetter(value[0]) && value.Length == 5);
            Multinomial.Add(value, p);
        } 
 
        internal override Dictionary<Hla, double> Evaluate(HlaCollection hlaCollection)
        { 
            return Multinomial;
        }

        public override int Count
        {
            get { return Multinomial.Count; } 
        } 

    } 

}

// Microsoft Research, Machine Learning and Applied Statistics Group, Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved.
