using System; 
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.IO;
using Msr.Mlas.SpecialFunctions; 
using Msr.Linkdis; 
using VirusCount.Qmrr;
using EpipredLib; 
using System.Reflection;
using VirusCount;

namespace Msr.Linkdis
{
    public class MulticlassLogisticRegression : HlaDistribution 
    { 
        private MulticlassLogisticRegression()
        { 
        }

        private Dictionary<string, double[]> FeatureNameToWeightVector;
        public static HlaDistribution GetInstance(HlaFactory hlaFactory, string target,
            string[] givenHlaClassCollection, string weightFile, SerialNumbers<string> featureSerialNumbers, SerialNumbers<string> classSerialNumbers)
        { 
            SpecialFunctions.CheckCondition(weightFile.EndsWith(".weights.txt")); //!!!raise error 
            List<Hla> stateCollection = CreateStateSpace(hlaFactory, classSerialNumbers);
 
            MulticlassLogisticRegression multiclassLogisticRegression = new MulticlassLogisticRegression();
            multiclassLogisticRegression.StateCollection = stateCollection;
            multiclassLogisticRegression.FeatureNameToWeightVector = new Dictionary<string,double[]>();
            multiclassLogisticRegression.GivenHlaClassCollection = givenHlaClassCollection;

 
            using (TextReader textReader = File.OpenText(weightFile)) 
            {
                string line = textReader.ReadLine(); 
                string addedFeatureText = @"*Added feature";
                SpecialFunctions.CheckCondition(line.StartsWith(addedFeatureText));
                int addedFeatureIndex = int.Parse(line.Substring(addedFeatureText.Length));
                SpecialFunctions.CheckCondition(addedFeatureIndex == featureSerialNumbers.Count);
                int featureCount = 0;
                while(null != (line = textReader.ReadLine())) 
                { 
                    ++featureCount;
                    string[] fieldCollection = line.Split('\t'); 
                    SpecialFunctions.CheckCondition(fieldCollection.Length == classSerialNumbers.Count + 1);
                    int iFeature = int.Parse(fieldCollection[0]);
                    SpecialFunctions.CheckCondition(featureCount - 1 == iFeature);
                    string featureName = iFeature == addedFeatureIndex ? "" : featureSerialNumbers.GetItem(iFeature);
                    double[] weightVector = new double[classSerialNumbers.Count];
                    for(int classIndex = 0; classIndex < classSerialNumbers.Count; ++classIndex) 
                    { 
                        double weight = double.Parse(fieldCollection[classIndex + 1]);
                        weightVector[classIndex] = weight; 
                    }
                    multiclassLogisticRegression.FeatureNameToWeightVector.Add(featureName, weightVector);
                }
            }
            return multiclassLogisticRegression;
        } 
 

 

        static private List<Hla> CreateStateSpace(HlaFactory hlaFactory, SerialNumbers<string> classSerialNumbers)
        {
            List<Hla> stateCollection = new List<Hla>();
            foreach( string hlaName in classSerialNumbers.Items())
            { 
                Hla state = hlaFactory.GetGroundInstance(hlaName); 
                stateCollection.Add(state);
            } 
            return stateCollection;
        }

        private List<Hla> StateCollection;
        string[] GivenHlaClassCollection;
 
        internal override Dictionary<Hla, double> Evaluate(HlaCollection hlaCollection) 
        {
            Dictionary<string, string> caseSet = HlaDistribution.GenerateCaseForGivenVariables(hlaCollection, GivenHlaClassCollection); 
            if (null == caseSet)
            {
                return null;
            }
            double[] totalWeightVector = new double[StateCollection.Count]; // C# inits to 0's
 
            caseSet.Add("", "1"); // add always one feature 
            foreach (string featureName in caseSet.Keys)
            { 
                if (FeatureNameToWeightVector.ContainsKey(featureName))
                {
                    double[] weightVector = FeatureNameToWeightVector[featureName];
                    Debug.Assert(weightVector.Length == totalWeightVector.Length);
                    for (int iClass = 0; iClass < weightVector.Length; ++iClass)
                    { 
                        totalWeightVector[iClass] += weightVector[iClass]; 
                    }
                } 
            }

            double totalTotalExp = 0.0;
            double[] totalExpVector = new double[StateCollection.Count];
            for (int iClass = 0; iClass < totalWeightVector.Length; ++iClass)
            { 
                totalExpVector[iClass] = Math.Exp(totalWeightVector[iClass]); 
                totalTotalExp += totalExpVector[iClass];
            } 

            Dictionary<Hla, double> hlaToProbability = new Dictionary<Hla, double>();
            for (int iClass = 0; iClass < totalWeightVector.Length; ++iClass)
            {
                double probability = totalExpVector[iClass] / totalTotalExp;
                hlaToProbability.Add(StateCollection[iClass], probability); 
 
            }
 
            return hlaToProbability;

        }

        public override int Count
        { 
            get { return StateCollection.Count; } 
        }
    } 
}

// Microsoft Research, Machine Learning and Applied Statistics Group, Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved.
