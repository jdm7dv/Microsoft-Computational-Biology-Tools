using System; 
using System.Collections.Generic;
using System.Text;
using Msr.Mlas.SpecialFunctions;
using VirusCount;
using EpipredLib;
using System.Diagnostics; 
using System.IO; 
using System.Reflection;
using VirusCount.Qmrr; 

namespace Msr.Linkdis
{
    public abstract class HlaDistribution
    {
        abstract public int Count { get;} 
 
        internal static HlaDistribution GetInstance(Hla value)
        { 
            Unconditional unconditional = new Unconditional();
            unconditional.Add(value, 1.0);
            return unconditional;
        }

        abstract internal Dictionary<Hla, double> Evaluate(HlaCollection hlaCollection); 
 
        public Dictionary<Hla, double> Contrained(HlaCollection hlaCollection, Hla abstractHla)
        { 
            Dictionary<Hla, double> multinomialIn = Evaluate(hlaCollection);

            if (abstractHla.ToString().Length == 5 && abstractHla.ToString().Substring(3, 2) == "??")
            {
                return multinomialIn;
            } 
 
            double total = 0.0;
            foreach (Hla value in multinomialIn.Keys) 
            {
                if (abstractHla.IsMoreGeneralThan(value))
                {
                    total += multinomialIn[value];
                }
            } 
            if (total == 0) 
            {
                return null; 
            }
            else
            {
                Dictionary<Hla, double> multinomialOut = new Dictionary<Hla, double>();
                foreach (Hla value in multinomialIn.Keys)
                { 
                    if (abstractHla.IsMoreGeneralThan(value)) 
                    {
                        multinomialOut.Add(value, multinomialIn[value] / total); 
                    }
                }

                return multinomialOut;
            }
        } 
 

        private static bool CaseIsComplete(HlaCollection hlaCollection, Hla hla, string[] givenHlaClassCollection) 
        {
            if (!hla.IsGround)
            {
                return false;
            }
 
            foreach (string preceedingHlaClass in givenHlaClassCollection) 
            {
                foreach (Hla preceedingHla in hlaCollection.ByClass(preceedingHlaClass)) 
                {
                    if (!preceedingHla.IsGround)
                    {
                        return false;
                    }
                } 
            } 
            return true;
        } 

        //private static bool ValueIsCompleteOnColumn(string value)
        //{
        //    bool b = Linkdis.lnnnnPattern.IsMatch(value);
        //    SpecialFunctions.CheckCondition(b
        //            ||value == "" 
        //            || value == "NULL" 
        //            || Linkdis.lnnqqPattern.IsMatch(value)
        //            || Linkdis.lnnPattern.IsMatch(value) 
        //            || Linkdis.lPattern.IsMatch(value)
        //            || Linkdis.lnn0n_nPattern.IsMatch(value)
        //            || Linkdis.lnn_nn_nnnnPattern.IsMatch(value)
        //            || Linkdis.lnnnn_nnnnPattern.IsMatch(value),
        //            string.Format("The value ({0}) is not in a known format.", value));
        //    return b; 
        //} 

        internal static Dictionary<string, HlaDistribution> GetCollection( 
                HlaFactory hlaFactory,
                IEnumerable<KeyValuePair<string, HlaCollection>> trainingList,
                LearnModelDelegate learnModelDelegate,
                double smoothingParameter,
                string targetHlaClass, // e.g. "B"
                params string[] givenHlaClassCollection 
            ) 
        {
 
            Dictionary<string, List<Dictionary<string, string>>> trainingDataForEveryTarget = CreateTrainingDataForEveryTarget(trainingList, targetHlaClass, givenHlaClassCollection);
            Dictionary<string, HlaDistribution> targetToModel = CreateTargetToModel(hlaFactory, learnModelDelegate, givenHlaClassCollection, trainingDataForEveryTarget, smoothingParameter);

            return targetToModel;
        }
 
        private static Dictionary<string, HlaDistribution> CreateTargetToModel(HlaFactory hlaFactory, LearnModelDelegate learnModelDelegate, string[] givenHlaClassCollection, Dictionary<string, List<Dictionary<string, string>>> trainingDataForEveryBTarget, double smoothingParameter) 
        {
            Dictionary<string, HlaDistribution> targetToModel = new Dictionary<string, HlaDistribution>(); 
            foreach (KeyValuePair<string, List<Dictionary<string, string>>> targetAndTrainingData in trainingDataForEveryBTarget)
            {
                HlaDistribution learnModel = learnModelDelegate(hlaFactory, targetAndTrainingData, givenHlaClassCollection, smoothingParameter);
                targetToModel.Add(targetAndTrainingData.Key, learnModel);
            }
            return targetToModel; 
        } 

        private static Dictionary<string, List<Dictionary<string, string>>> CreateTrainingDataForEveryTarget(IEnumerable<KeyValuePair<string, HlaCollection>> trainingList, string targetHlaClass, string[] givenHlaClassCollection) 
        {
            Dictionary<string, List<Dictionary<string, string>>> trainingDataForEveryTarget
                                    = new Dictionary<string, List<Dictionary<string, string>>>();

            foreach (KeyValuePair<string, HlaCollection> patientAndHlaCollection in trainingList)
            { 
                HlaCollection hlaCollectionOrNull = patientAndHlaCollection.Value; 

                SpecialFunctions.CheckCondition(hlaCollectionOrNull != null && hlaCollectionOrNull.Weight == 1.0); 
                foreach (Hla targetHla in hlaCollectionOrNull.ByClass(targetHlaClass))
                {
                    if (!CaseIsComplete(hlaCollectionOrNull, targetHla, givenHlaClassCollection))
                    {
                        continue;
                    } 
 
                    KeyValuePair<string, string> targetVariableAndValue = Linkdis.GetVariableAndValue(targetHla);
 
                    List<Dictionary<string, string>> trainingDataForThisTarget = SpecialFunctions.GetValueOrDefault(trainingDataForEveryTarget, targetVariableAndValue.Key);
                    Dictionary<string, string> caseSet = GenerateCase(hlaCollectionOrNull, targetVariableAndValue, givenHlaClassCollection);
                    trainingDataForThisTarget.Add(caseSet);
                }
            }
            return trainingDataForEveryTarget; 
        } 

 


        static public Dictionary<string, string> GenerateCase(HlaCollection hlaCollection, KeyValuePair<string, string> targetVariableAndValue, string[] givenHlaClassCollection)
        {
            Dictionary<string, string> caseSet = GenerateCaseForGivenVariables(hlaCollection, givenHlaClassCollection);
            caseSet.Add(targetVariableAndValue.Key, targetVariableAndValue.Value); 
            return caseSet; 
        }
 
        public static Dictionary<string, string> GenerateCaseForGivenVariables(HlaCollection hlaCollection, string[] givenHlaClassCollection)
        {
            Dictionary<string, string> caseSet = new Dictionary<string, string>();
            foreach (string aHlaClass in givenHlaClassCollection)
            {
                int sizeBefore = caseSet.Count; 
 
                foreach (Hla givenHla in hlaCollection.ByClass(aHlaClass))
                { 
                    if (!givenHla.IsGround)
                    {
                        return null;
                    }
                    Debug.Assert(givenHla.ToString().Length == 5); // real assert
                    caseSet[givenHla.ToString()] = "1"; 
                } 
                if (sizeBefore + 1 == caseSet.Count)
                { 
                    string aVariable = string.Format("{0}{1}", aHlaClass, "Same");
                    caseSet.Add(aVariable, "1");
                }
                SpecialFunctions.CheckCondition(sizeBefore + 2 == caseSet.Count);
            }
            return caseSet; 
        } 

 

        public static HlaDistribution LearnWinmineModel(HlaFactory hlaFactory, KeyValuePair<string, List<Dictionary<string, string>>> targetAndTrainingData, string[] givenHlaClassCollection, double smoothingParameter)
        {

            string tempDirectoryName = Path.GetTempPath() + @"\WinMine\";
            Directory.CreateDirectory(tempDirectoryName); 
            string target = targetAndTrainingData.Key; 
            List<Dictionary<string, string>> trainingSet = targetAndTrainingData.Value;
            HlaDistribution aHlaDistribution = HlaDistribution.GetInstance(hlaFactory, target, trainingSet); 

            if (aHlaDistribution.Count > 1)
            {
                string txtFile = CreateWinMineTxtFile(tempDirectoryName, target, trainingSet);
                string xdatFile = ConvertRawDataSparse(tempDirectoryName, target, txtFile);
                string xplanFile = CreateXPlan(tempDirectoryName, target, xdatFile); 
                string xmodFile = RunDnet(tempDirectoryName, target, xdatFile, xplanFile, smoothingParameter); 
                return DecisionTree.GetInstance(hlaFactory, target, givenHlaClassCollection, xmodFile);
            } 
            else
            {
                return aHlaDistribution;
            }
        }
 
        static private string RunDnet(string tempDirectoryName, string target, string xdatFile, string xplanFile, double kappa) 
        {
            string xmodFile = string.Format("{0}{1}{2}", tempDirectoryName, target, ".xmod"); 
            RunProgram(WinMineExeDirectory, "dnet.exe", string.Format(@"-data ""{0}"" -plan ""{1}"" -model ""{2}"" -ksqmarg 2 -kappa {3}", xdatFile, xplanFile, xmodFile, kappa));
            return xmodFile;
        }


        static public string CreateXPlan(string directoryName, string target, string xdatFile) 
        { 
            string xplanFile = string.Format("{0}{1}{2}", directoryName, target, ".xplan");
            return CreateXPlan(directoryName, target, xdatFile, xplanFile); 

        }
        static public string CreateXPlan(string directoryName, string target, string xdatFile, string xplanFile)
        {
            string s = string.Format(@"
<?xml version=""1.0"" standalone=""yes""?> 
<AnalysisNotebook> 
 	<ModelPlan>
		<VariableSourceFile name=""{0}""/> 
		<VariableRoles>
			<DefaultVariableRole role=""input""/>
			<VariableRole variable=""{1}"" role=""output""/>
		</VariableRoles>
 		<ModelAsBinaryInfo>
 		</ModelAsBinaryInfo> 
		<Distributions> 
 			<DefaultCategoricalDistribution type=""tree-multinomial""/>
		</Distributions> 
	</ModelPlan>
</AnalysisNotebook>
            ", xdatFile, target);

            using (TextWriter streamWriter = File.CreateText(xplanFile))
            { 
                streamWriter.WriteLine(s); 
            }
            return xplanFile; 

        }

        static private string WinMineExeDirectory
        {
            get 
            { 
                string exeDirectoryName = Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetModules()[0].FullyQualifiedName); // See MSDN titled: How to: Get the Application Directory
                return exeDirectoryName; 
            }
        }

        static private string ConvertRawDataSparse(string tempDirectoryName, string target, string txtFile)
        {
            string xdatFile = string.Format("{0}{1}{2}", tempDirectoryName, target, ".xdat"); 
            RunProgram(WinMineExeDirectory, "convertrawdata.exe", string.Format(@"-sparse -fdelim 1 -from ""{0}"" -to ""{1}""", txtFile, xdatFile)); 
            return xdatFile;
        } 

        static private string CreateWinMineTxtFile(string tempDirectoryName, string target, List<Dictionary<string, string>> trainingSet)
        {
            string txtFile = string.Format(@"{0}{1}{2}", tempDirectoryName, target, ".txt");
            using (TextWriter streamWriter = File.CreateText(txtFile))
            { 
                for (int iCase = 0; iCase < trainingSet.Count; ++iCase) 
                {
                    Dictionary<string, string> winmineCase = trainingSet[iCase]; 
                    foreach (KeyValuePair<string, string> variableAndValue in winmineCase)
                    {
                        streamWriter.WriteLine("{0}\t{1}\t{2}", iCase, variableAndValue.Key, variableAndValue.Value);
                    }
                }
            } 
            return txtFile; 
        }
 
        internal static HlaDistribution GetInstance(HlaFactory hlaFactory, string target, List<Dictionary<string, string>> trainingSet)
        {
            return GetInstance(hlaFactory, target, trainingSet, 0.0);
        }

 
        internal static HlaDistribution GetInstance(HlaFactory hlaFactory, string target, List<Dictionary<string, string>> trainingSet, double sampleSize) 
        {
            Dictionary<Hla, double> countValues = new Dictionary<Hla, double>(); 
            double total = 0;
            foreach (Dictionary<string, string> row in trainingSet)
            {
                Hla value = hlaFactory.GetGroundInstance(row[target]);
                countValues[value] = 1 + SpecialFunctions.GetValueOrDefault(countValues, value, sampleSize);
                ++total; 
            } 
            total += sampleSize * countValues.Count;
 
            Unconditional unconditional = new Unconditional();
            foreach (KeyValuePair<Hla, double> valueAndCount in countValues)
            {
                unconditional.Add(valueAndCount.Key, valueAndCount.Value / total);
            }
            return unconditional; 
        } 

        static public void RunProgram(string exeDirectory, string programFile, string arguments) 
        {
            TimeSpan timeOut = new TimeSpan(0, 2, 0); // 2 minutes //!!!const

            ProcessStartInfo aProcessStartInfo = new ProcessStartInfo();
            aProcessStartInfo.FileName = string.Format(@"{0}\{1}", exeDirectory, programFile);
            SpecialFunctions.CheckCondition(File.Exists(aProcessStartInfo.FileName), string.Format("External program not found ({0})", aProcessStartInfo.FileName)); //!!!raise error 
            aProcessStartInfo.Arguments = arguments; 
            Debug.WriteLine(string.Format(@"""{0}"" {1}", aProcessStartInfo.FileName, aProcessStartInfo.Arguments));
            aProcessStartInfo.RedirectStandardError = true; 
            aProcessStartInfo.RedirectStandardOutput = true;
            aProcessStartInfo.UseShellExecute = false;
            aProcessStartInfo.CreateNoWindow = true;
            Process processExe = Process.Start(aProcessStartInfo);//!!!gets stuck with *.exe crashes
            string sStdOut = processExe.StandardOutput.ReadToEnd(); //must read first to avoid deadlock (for details: search Google or MSDN for: StandardError.ReadToEnd deadlock
            Debug.WriteLine(sStdOut); 
            processExe.WaitForExit(timeOut.Milliseconds); 
            Debug.Assert(processExe.HasExited); //!!!handle the timeout case
            SpecialFunctions.CheckCondition(processExe.ExitCode == 0); //!!!handle error from the *.exe 
        }


    }
}
 
// Microsoft Research, Machine Learning and Applied Statistics Group, Shared Source. 
// Copyright (c) Microsoft Corporation. All rights reserved.
