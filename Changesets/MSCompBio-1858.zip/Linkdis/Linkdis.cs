using System; 
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.IO;
using Msr.Mlas.SpecialFunctions; 
using VirusCount; 
using EpipredLib;
using VirusCount.Qmrr; 

namespace Msr.Linkdis
{

    public delegate HlaDistribution LearnModelDelegate(HlaFactory hlaFactory, KeyValuePair<string, List<Dictionary<string, string>>> targetAndTrainingData, string[] givenHlaClassCollection, double smoothingParameter);
 
 	public class Linkdis 
	{
		private Linkdis() 
		{
		}

        public static string DefaultLearner = "softmax";
        public static Dictionary<string, double> LearnerToDefaultSmoothingParameter = CreateLearnerToDefaultSmoothingParameter();
 
        private static Dictionary<string, double> CreateLearnerToDefaultSmoothingParameter() 
        {
            Dictionary<string, double> learnerToDefaultSmoothingParameter = new Dictionary<string, double>(); 
            learnerToDefaultSmoothingParameter.Add("softmax", 2.0);
            //learnerToDefaultSmoothingParameter.Add("winmine", 0.3);
            //learnerToDefaultSmoothingParameter.Add("multinomial", 0);
            Debug.Assert(learnerToDefaultSmoothingParameter.ContainsKey(DefaultLearner)); // real assert
            return learnerToDefaultSmoothingParameter;
 
        } 
        public static IEnumerable<string> LearnerEnumeration
        { 
            get
            {
                return LearnerToDefaultSmoothingParameter.Keys;
            }
        }
 
        public static Linkdis GetInstance(string trainingFileName, string learnerName, double smoothingParameter) 
        {
            using (TextReader textReader = File.OpenText(trainingFileName)) 
            {
                return GetInstance(textReader, learnerName, smoothingParameter);
            }
        }

 
        public static Linkdis GetInstance(TextReader textReader, string learnerName, double smoothingParameter) 
        {
            PatientToHlaCollection trainingTable = HlaTable(textReader); 
            return GetInstance(learnerName, smoothingParameter, trainingTable.PatientAndHlaCollectionOrNull());
        }

        public static Linkdis GetInstance(string learnerName, double smoothingParameter, IEnumerable<KeyValuePair<string, HlaCollection>> trainingList)
        {
            Linkdis aLinkdis = new Linkdis(); 
            aLinkdis.LearnModelDelegate = GetLearnModelDelegate(learnerName); 
            aLinkdis.TrainInternal(trainingList, smoothingParameter);
            return aLinkdis; 
        }



        //internal static Regex lnnnnPattern = new Regex("^[ABC](?<left>[0-9]{2,2})(?<right>[-0-9][-0-9])$");
        //internal static Regex lnnqqPattern = new Regex("^[ABC](?<left>[0-9][0-9])(?<right>[?][?])$"); 
        //internal static Regex lnnPattern = new Regex("^[ABC](?<left>[0-9][0-9])$"); 
        //internal static Regex lPattern = new Regex("^[ABC]$");
        //internal static Regex lnn0n_nPattern = new Regex("^[ABC](?<left>[0-9][0-9])0(?<right1>[0-9])/(?<right2>[0-9])$"); 
        //internal static Regex lnnnn_nnnnPattern = new Regex("^[ABC]((?<left1>[0-9][0-9])(?<right1>[0-9][0-9]))/((?<left2>[0-9][0-9])(?<right2>[0-9][0-9]))$");
        //internal static Regex lnn_nn_nnnnPattern = new Regex("^[ABC]((?<left1>[0-9][0-9]))/((?<left2>[0-9][0-9]))/((?<left3>[0-9][0-9])(?<right3>[0-9][0-9]))$");
        //internal static Regex lninethousandOrMore = new Regex("^[ABC]9[0-9][0-9][0-9]$");


        //static string[] AColumns = new string[]{"A1", "A2"}; 
        //static string[] BColumns = new string[]{"B1", "B2"}; 
        //static string[] CColumns = new string[] { "C1", "C2"};
 
        public Dictionary<string, Dictionary<string, HlaDistribution>> HlaClassToTargetToHlaDistribution;


        LearnModelDelegate LearnModelDelegate;
        static HlaFactory HlaFactory = HlaFactory.GetFactory("FourDigit");
        private void TrainInternal(IEnumerable<KeyValuePair<string, HlaCollection>> trainingList, double smoothingParameter) 
		{ 
            HlaClassToTargetToHlaDistribution = new Dictionary<string, Dictionary<string, HlaDistribution>>();
            HlaClassToTargetToHlaDistribution.Add("A", HlaDistribution.GetCollection(HlaFactory, trainingList, LearnModelDelegate, smoothingParameter, "A")); 
 			Debug.Assert(HlaClassToTargetToHlaDistribution["A"].Count > 0); // real assert
            HlaClassToTargetToHlaDistribution.Add("B", HlaDistribution.GetCollection(HlaFactory, trainingList, LearnModelDelegate, smoothingParameter, "B", "A"));
            HlaClassToTargetToHlaDistribution.Add("C", HlaDistribution.GetCollection(HlaFactory, trainingList, LearnModelDelegate, smoothingParameter, "C", "A", "B"));
 		}

        public void ExpandAndReport(string inputFileName, string expandedFileName, string lineByLineFileName) 
        { 
            using (TextReader inputText = File.OpenText(inputFileName))
            { 
                using (TextWriter expandedText = File.CreateText(expandedFileName),
                    lineByLineText = File.CreateText(lineByLineFileName))
                {
                    ExpandAndReport(inputText, expandedText, lineByLineText);
                }
            } 
        } 
        public void ExpandAndReport(TextReader inputText, TextWriter expandedText, TextWriter lineByLineText)
        { 
            PatientToHlaCollection testingTable = HlaTable(inputText);
            PatientToHlaCollection dataExpandedOnABC = Expand(testingTable.PatientAndHlaCollectionOrNull());

			if (expandedText != null)
 			{
				DisplayRows(expandedText, dataExpandedOnABC); 
			} 

			if (lineByLineText != null) 
			{
				ShowExpansion(lineByLineText, testingTable, dataExpandedOnABC);
 			}
        }

        private PatientToHlaCollection Expand(IEnumerable<KeyValuePair<string, HlaCollection>> testingList) 
        { 
            PatientToHlaCollection dataExpandedOnA = PatientToHlaCollection.GetExpandedInstance(testingList, "A", HlaClassToTargetToHlaDistribution["A"]);
            PatientToHlaCollection dataExpandedOnAB = PatientToHlaCollection.GetExpandedInstance(dataExpandedOnA.PatientAndHlaCollectionOrNull(), "B", HlaClassToTargetToHlaDistribution["B"]); 
            PatientToHlaCollection dataExpandedOnABC = PatientToHlaCollection.GetExpandedInstance(dataExpandedOnAB.PatientAndHlaCollectionOrNull(), "C", HlaClassToTargetToHlaDistribution["C"]);
            return dataExpandedOnABC;
        }


        internal static KeyValuePair<string, string> GetVariableAndValue(Hla hlaTarget) 
        { 
            Debug.Assert(hlaTarget.IsGround && hlaTarget.ToString().Length == 5); // real assert
            string aValue = hlaTarget.ToString(); 
            string aVariable = aValue.Substring(0, 3);
            return new KeyValuePair<string, string>(aVariable, aValue);
        }

        //internal static string CreateValue(string aHlaClass, string aNNNN)
        //{ 
        //    SpecialFunctions.CheckCondition(aHlaClass[0] == aNNNN[0]); 
        //    if (aNNNN.Length == 4)
        //    { 
        //        string s = string.Format("{0}0{1}", aHlaClass, aNNNN.Substring(1));
        //        return s;
        //    }
        //    else
        //    {
        //        SpecialFunctions.CheckCondition(aNNNN.Length == 5); 
        //        //string s = string.Format("{0}{1}", aHlaClass, aNNNN); 
        //        return aNNNN;
        //    } 
        //}

        //private static string CreateVariable(string aHlaClass, int aLeft)
        //{
        //    string s = string.Format("{0}{1:00}", aHlaClass, aLeft);
        //    return s; 
        //} 

 

        ////nn0n_nPattern
        //private static string GetVariableFromSlashed1(KeyValuePair<string, HlaCollection> row, string aColumn, out string[] valueCollection)
        //{
        //    string aHlaClass = aColumn.Substring(0, 1);
        //    string ann0n_n = row[aColumn]; 
        //    Match aMatch = lnn0n_nPattern.Match(ann0n_n); 
        //    Debug.Assert(aMatch.Success); // real assert
        //    int aLeft = int.Parse(aMatch.Groups["left"].Value); 
        //    string aVariable = string.Format("{0}{1}", aHlaClass, aLeft);
        //    Debug.Assert(aVariable.Length == 3); // real assert

        //    string value1 = string.Format("{0}0{1}", aVariable, aMatch.Groups["right1"].Value);
        //    string value2 = string.Format("{0}0{1}", aVariable, aMatch.Groups["right2"].Value);
        //    Debug.Assert(value1.Length == 5 && value2.Length == 5); // real assert 
 
        //    valueCollection = new string[] { value1, value2 };
        //    return aVariable; 
        //}

        ////nnnn_nnnnPattern
        //private static string GetVariableFromSlashed2(KeyValuePair<string, HlaCollection> row, string aColumn, out string[] valueCollection)
        //{
        //    string aHlaClass = aColumn.Substring(0, 1); 
        //    string aNNNN_NNNN = row[aColumn]; 
        //    Match aMatch = lnnnn_nnnnPattern.Match(aNNNN_NNNN);
        //    Debug.Assert(aMatch.Success); // real assert 
        //    int aLeft = int.Parse(aMatch.Groups["left1"].Value);
        //    SpecialFunctions.CheckCondition(aLeft == int.Parse(aMatch.Groups["left2"].Value));
        //    string aVariable = string.Format("{0}{1:00}", aHlaClass, aLeft);
        //    Debug.Assert(aVariable.Length == 3); // real assert

        //    string value1 = string.Format("{0}{1}", aVariable, aMatch.Groups["right1"].Value); 
        //    string value2 = string.Format("{0}{1}", aVariable, aMatch.Groups["right2"].Value); 
        //    Debug.Assert(value1.Length == 5 && value2.Length == 5); // real assert
 
        //    valueCollection = new string[] { value1, value2 };
        //    return aVariable;
        //}


        //private static string GetVariable(KeyValuePair<string, HlaCollection> row, string aColumn) 
        //{ 
        //    string aHlaClass = aColumn.Substring(0, 1);
        //    string aNNxx = row[aColumn]; 
        //    Match aMatch = lnnqqPattern.Match(aNNxx);
        //    Debug.Assert(aMatch.Success); // real assert
        //    string aLeft = aMatch.Groups["left"].Value;
        //    string aVariable = string.Format("{0}{1}", aHlaClass, aLeft);
        //    Debug.Assert(aVariable.Length == 3); // real assert
        //    return aVariable; 
        //} 

 

        private static void DisplayRows(TextWriter streamWriter, PatientToHlaCollection expandedTable)
        {
            streamWriter.WriteLine(@"pid	A1	A2	B1	B2	C1	C2	Weight");
            foreach (KeyValuePair<string, List<HlaCollection>> patientAndHlaCollectionList in expandedTable.PatientAndHlaCollectionList())
            { 
                DisplayRow(patientAndHlaCollectionList, streamWriter); 
            }
        } 


        private static void DisplayRow(KeyValuePair<string, List<HlaCollection>> patientAndHlaCollectionList, TextWriter streamWriter)
        {
            string pid = patientAndHlaCollectionList.Key;
            List<HlaCollection> hlaCollectionList = patientAndHlaCollectionList.Value; 
            if (hlaCollectionList.Count == 0) 
            {
                streamWriter.WriteLine(SpecialFunctions.CreateTabString(pid, "No expansion with positive probability found")); 
            }
            else
            {
                foreach(HlaCollection hlaCollection in hlaCollectionList)
                {
                    streamWriter.WriteLine(SpecialFunctions.CreateTabString(pid, hlaCollection).Replace("@","")); 
                } 
            }
        } 

        private void ShowExpansion(TextWriter streamWriter, PatientToHlaCollection testingTable, PatientToHlaCollection dataExpandedOnABC)
        {
            streamWriter.WriteLine(@"pid	A1	A2	B1	B2	C1	C2	Weight");

            foreach (KeyValuePair<string, List<HlaCollection>> originalPatientAndHlaCollectionList in testingTable.PatientAndHlaCollectionList()) 
            { 
                Debug.Assert(originalPatientAndHlaCollectionList.Value.Count == 1); // real assert
 
                string pid = originalPatientAndHlaCollectionList.Key;

                List<HlaCollection> expandedHlaCollectionList = dataExpandedOnABC.GetHlaCollectionList(pid);
                if (expandedHlaCollectionList.Count != 1)
                {
                    DisplayRow(originalPatientAndHlaCollectionList, streamWriter); 
                    KeyValuePair<string, List<HlaCollection>> expandedPatientAndHlaCollectionList = new KeyValuePair<string, List<HlaCollection>>(pid, expandedHlaCollectionList); 
                    DisplayRow(expandedPatientAndHlaCollectionList, streamWriter);
                } 
            }
        }


        static private PatientToHlaCollection HlaTable(TextReader textReader)
 		{ 
            PatientToHlaCollection fromFile = PatientToHlaCollection.GetInstance(HlaFactory, textReader); 
            PatientToHlaCollection lessAbstract = PatientToHlaCollection.GetLessAbstractInstance(fromFile);
            return lessAbstract; 
		}




        //!!! instead of a delegate, could have subclasses 
        private static LearnModelDelegate GetLearnModelDelegate(string learnerName) 
        {
            //!!!switch to switch 
            if (learnerName == "winmine")
            {
                return HlaDistribution.LearnWinmineModel;
            }
            else if (learnerName == "softmax")
            { 
                return (new HlaLogisticRegression()).LearnLogisticRegressionModel; 
            }
            else if (learnerName == "multinomial") 
            {
                return HlaMultinomial.LearnMultinomial;
            }
            else
            {
                SpecialFunctions.CheckCondition(false, string.Format("learnerName ({0}) not known", learnerName)); 
                return null; 
            }
        } 


        public static double CrossValidationScore(TextReader trainingText, string[] hlaClassOrder, string learnerName, double smoothingParameter, int foldCount, int randomSeed, out int itemsScoredCount)
        {
            Random random = new Random(randomSeed);
 
            SpecialFunctions.CheckCondition(hlaClassOrder.Length == 3 && hlaClassOrder[0] == "A" && hlaClassOrder[1] == "B" && hlaClassOrder[2] == "C", "only have code for this hlaClassOrder"); 

            PatientToHlaCollection trainingTable = HlaTable(trainingText); 

            double totalScore = 0.0;
            itemsScoredCount = 0;

            SplitForCrossValidation<KeyValuePair<string, HlaCollection>> splitForCrossValidation = SplitForCrossValidation<KeyValuePair<string, HlaCollection>>.GetInstance(trainingTable.PatientAndHlaCollectionOrNull(), 10, ref random);
            foreach (KeyValuePair<IEnumerable<KeyValuePair<string, HlaCollection>>, IEnumerable<KeyValuePair<string, HlaCollection>>> 
                      trainAndTest in splitForCrossValidation.TrainAndTestCollection()) 
            {
                IEnumerable<KeyValuePair<string, HlaCollection>> trainList = trainAndTest.Key; 
                IEnumerable<KeyValuePair<string, HlaCollection>> testList = trainAndTest.Value;

                Linkdis linkdis = GetInstance(learnerName, smoothingParameter, trainList);

                foreach (KeyValuePair<string, HlaCollection> pidAndHlaCollection in testList)
                { 
                    HlaCollection hlaCollection = pidAndHlaCollection.Value; 
                    totalScore += linkdis.ScoreHlaCollection(hlaCollection, ref itemsScoredCount);
                } 
            }

            return totalScore;

        }
 
        private double ScoreHlaCollection(HlaCollection hlaCollection, ref int itemsScoredCount) 
        {
            double subTotalScore = 0; 
            Debug.Assert(hlaCollection.Weight == 1.0); // real assert
            foreach (string hlaClass in hlaCollection.ClassList())
            {
                int itemsScoredCountBefore = itemsScoredCount;
                subTotalScore += ScoreHlaClass(hlaClass, hlaCollection, ref itemsScoredCount);
                if (itemsScoredCount < itemsScoredCountBefore + 2) //e.g. If one of the A's is not grounded, we skip the B's and C's 
                { 
                    break;
                } 
            }
            return subTotalScore;
        }

        private double ScoreHlaClass(string hlaClass, HlaCollection hlaCollection, ref int itemsScoredCount)
        { 
            double subTotalScore = 0.0; 
            Dictionary<string, HlaDistribution> targetToModel = HlaClassToTargetToHlaDistribution[hlaClass];
            foreach (Hla hla in hlaCollection.ByClass(hlaClass)) 
            {
                if (hla.IsGround)
                {
                    SpecialFunctions.CheckCondition(hla.ToString().Length == 5);
                    string target = hla.ToString().Substring(0, 3);
                    if (targetToModel.ContainsKey(target)) 
                    { 
                        HlaDistribution hlaDistributionAll = targetToModel[target];
                        Dictionary<Hla, double> multinomial = hlaDistributionAll.Evaluate(hlaCollection); 
                        if (multinomial.ContainsKey(hla))
                        {
                            double probabilityOfOutcome = multinomial[hla];
                            subTotalScore += Math.Log(probabilityOfOutcome);
                            ++itemsScoredCount;
                        } 
                    } 
                }
            } 
            return subTotalScore;
        }

    }

 
} 

 
// Microsoft Research, Machine Learning and Applied Statistics Group, Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved.
