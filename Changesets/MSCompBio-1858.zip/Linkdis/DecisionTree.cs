using System; 
using System.Collections.Generic;
using System.Text;
using Msr.Mlas.SpecialFunctions;
using VirusCount;
using EpipredLib;
using VirusCount.Qmrr; 
using System.Xml; 
using System.Diagnostics;
 
namespace Msr.Linkdis
{
    public class DecisionTree : HlaDistribution
    {
        private DecisionTree()
        { 
        } 

        public static HlaDistribution GetInstance(HlaFactory hlaFactory, string target, string[] givenHlaClassCollection, string xmodFileName) 
        {
            SpecialFunctions.CheckCondition(xmodFileName.EndsWith(".xmod")); //!!!raise error

            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load(xmodFileName); //!!!raise error
            //XmlNode xmlNodeDecisionTree = xmlDocument.SelectSingleNode("DecisionTree"); //!!!const 
            ConfirmIndexOfInputVariables(xmlDocument); 
            return ReadSplit(hlaFactory, target, givenHlaClassCollection, xmlDocument);
        } 


        static private void ConfirmIndexOfInputVariables(XmlDocument xmlDocument)
        {
            XmlNode state = xmlDocument.SelectSingleNode("Variables/TypeVariables/Variable/State[@index='1']");
            SpecialFunctions.CheckCondition(state == null || state.Attributes["name"].Value == "1"); 
        } 

        private string SplitNode; 
        private HlaDistribution[] BranchCollection;

        static public HlaDistribution ReadSplit(HlaFactory hlaFactory, string target, string[] givenHlaClassCollection, XmlDocument xmlDocument)
        {
            //DecisionTree/Leaf/Multinomial
            //DecisionTree/Vertex/Branch/[Values|Vertex] 
            //DecisionTree/Vertex/Branch/[Values|Leaf] 

            List<Hla> stateCollection = CreateStateSpace(hlaFactory, target, xmlDocument); 

            string localModelXPath = string.Format("//LocalModels/LocalModel[@variable='{0}']", target);
            XmlNode localModel = xmlDocument.SelectSingleNode(localModelXPath);
            SpecialFunctions.CheckCondition(localModel != null, "Expect target to have local model");

            string decisionTreePath = string.Format("DecisionTree"); 
            XmlNode decisionTreeNode = localModel.SelectSingleNode(decisionTreePath); 

            return LeafOrVertex(decisionTreeNode, stateCollection, givenHlaClassCollection); 

        }

        static public HlaDistribution LeafOrVertex(XmlNode parentNode, List<Hla> stateCollection, string[] givenHlaClassCollection)
        {
 
            XmlNode vertexNode = parentNode.SelectSingleNode("Vertex"); 

            if (vertexNode == null) 
            {
                //     <LocalModels>
                //        <LocalModel variable="B8">
                //            <DecisionTree>
                //                <Leaf>
                //                    <Multinomial> 
                //                        <Probs>0.965002 0.0231725 0.0118251</Probs> 
                //                        <Counts>85 2 1</Counts>
                //                        <PriorCounts>3.78022 0.131868 0.0879121</PriorCounts> 
                //                    </Multinomial>
                //                </Leaf>
                //            </DecisionTree>
                //        </LocalModel>
                //    </LocalModels>
                //</Model> 
 
                string[] probsAsStrings = parentNode.SelectSingleNode("Leaf/Multinomial/Probs").InnerText.Split(' ');
                SpecialFunctions.CheckCondition(probsAsStrings.Length == stateCollection.Count); 
                return Unconditional.GetInstance(stateCollection, probsAsStrings);
            }
            else
            {
                DecisionTree aDecisionTree = new DecisionTree();
                aDecisionTree.StateCollection = stateCollection; 
 
                aDecisionTree.SplitNode = vertexNode.Attributes["split"].Value;
                SpecialFunctions.CheckCondition(aDecisionTree.SplitNode.Length == 5); 

                XmlNodeList branchList = vertexNode.SelectNodes("Branch");
                SpecialFunctions.CheckCondition(branchList.Count == 2, "Expect there to be two branches");

                foreach (string givenHlaClass in givenHlaClassCollection)
                { 
                    if (givenHlaClass == aDecisionTree.SplitNode.Substring(0, 1)) 
                    {
                        aDecisionTree.HlaClass = givenHlaClass; 
                        break;
                    }
                }
                SpecialFunctions.CheckCondition(aDecisionTree.HlaClass != null);

                aDecisionTree.BranchCollection = new HlaDistribution[2]; 
 
                foreach (XmlNode branch in branchList)
                { 
                    int branchValue = int.Parse(branch.SelectSingleNode("Values").InnerText);
                    SpecialFunctions.CheckCondition(branchValue == 0 || branchValue == 1);
                    aDecisionTree.BranchCollection[branchValue] = LeafOrVertex(branch, stateCollection, givenHlaClassCollection);
                }

                return aDecisionTree; 
            } 

 
            //         <LocalModel variable="C3">
            //            <Inputs>
            //                <Input variable="B1510"/>
            //            </Inputs>
            //            <DecisionTree>
            //                <Vertex split="B1510" splitScore="13.6405" id="0"> 
            //                    <Branch> 
            //                        <Values>0</Values>
            //                        <Leaf> 
            //                            <Multinomial>
            //                                <Probs>0.463064 0.155267 0.381669</Probs>
            //                                <Counts>15 5 10</Counts>
            //                                <PriorCounts>0.744186 0.27907 2.97674</PriorCounts>
            //                            </Multinomial>
            //                        </Leaf> 
            //                    </Branch> 
            //                    <Branch>
            //                        <Values>1</Values> 
            //                        <Leaf>
            //                            <Multinomial>
            //                                <Probs>0.0130559 0.00489596 0.982048</Probs>
            //                                <Counts>0 0 53</Counts>
            //                                <PriorCounts>0.744186 0.27907 2.97674</PriorCounts>
            //                            </Multinomial> 
            //                        </Leaf> 
            //                    </Branch>
            //                </Vertex> 
            //            </DecisionTree>
            //        </LocalModel>
            //    </LocalModels>
            //</Model>

        } 
 

        static private List<Hla> CreateStateSpace(HlaFactory hlaFactory, string target, XmlDocument xmlDocument) 
        {
            //<AnalysisNotebook>
            //    <Variables>
            //        <TypeVariables>
            //            <Variable name="Type0 2-state" type="categorical">
            //                <State index="0" name="Not 1"/> 
            //                <State index="1" name="1"/> 
            //            </Variable>
            //        </TypeVariables> 
            //        <Variable name="C3" type="categorical">
            //            <State index="0" name="C302"/>
            //            <State index="1" name="C303"/>
            //            <State index="2" name="C304"/>
            //        </Variable>
 
            List<Hla> stateCollection = new List<Hla>(); 

            string sXpathExpression = string.Format("//Variables/Variable[@name='{0}']/State", target); 
            XmlNodeList xmlNodeList = xmlDocument.SelectNodes(sXpathExpression);
            SpecialFunctions.CheckCondition(xmlNodeList.Count > 0, "Expect target to have states");
            foreach (XmlNode xmlNode in xmlNodeList)
            {
                int index = int.Parse(xmlNode.Attributes["index"].Value);
                Debug.Assert(index == stateCollection.Count); // real assert 
                Hla state = hlaFactory.GetGroundInstance((string)xmlNode.Attributes["name"].Value); 
                stateCollection.Add(state);
            } 

            return stateCollection;
        }

        private List<Hla> StateCollection;
        string HlaClass; 
 
        internal override Dictionary<Hla, double> Evaluate(HlaCollection hlaCollection)
        { 
            Dictionary<string, string> caseSet = HlaDistribution.GenerateCaseForGivenVariables(hlaCollection, new string[] { HlaClass });
            if (null == caseSet)
            {
                return null;
            }
            HlaDistribution branch = BranchCollection[caseSet.ContainsKey(SplitNode) ? 1 : 0]; 
            if (branch is Unconditional) 
            {
                return ((Unconditional)branch).Multinomial; 
            }
            else
            {
                Debug.Assert(branch is DecisionTree); // realassert
                return branch.Evaluate(hlaCollection);
 
            } 
        }
 
        public override int Count
        {
            get { return StateCollection.Count; }
        }
    }
} 
 
// Microsoft Research, Machine Learning and Applied Statistics Group, Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved. 
