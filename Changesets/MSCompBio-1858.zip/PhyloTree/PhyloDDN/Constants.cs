using System;
using System.Collections.Generic;
using System.Text;

namespace PhyloDDN
{
    internal static class Constants {
        public const string TreeFileDefName = "TreeFile";
        public const string PredictorFileDefName = "PredictorFile";
        public const string TargetFileDefName = "TargetFile";
        public const string SkipRowIndexFileDefName = "SkipRowIndexFile";
    }
}
